const DEFAULT_CATALOG={shops:[{id:"s1",name:"Kedai Victory",address:"",map:"",hours:"",schedule:[],images:[],logo:""},{id:"s2",name:"Vision Vista",address:"",map:"",hours:"",schedule:[],images:[],logo:""}]};
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers}})}
function cookieValue(request,name){let c=request.headers.get("Cookie")||"";let m=c.match(new RegExp("(?:^|;\\s*)"+name.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\$&")+"=([^;]+)"));return m?decodeURIComponent(m[1]):""}
async function authed(request,env){let t=cookieValue(request,"olumajang_admin");return !!(t&&await env.CATALOG_KV.get("session:"+t))}
export default {async fetch(request,env){
 const url=new URL(request.url),p=url.pathname;
 if(p==="/api/catalog"&&request.method==="GET"){
  let x=await env.CATALOG_KV.get("catalog");return json(x?JSON.parse(x):DEFAULT_CATALOG);
 }
 if(p==="/api/login"&&request.method==="POST"){
  try{let b=await request.json();let expected=env.ADMIN_PASSWORD||"231288";if(String(b.password||"")!==String(expected))return json({ok:false},401);let token=crypto.randomUUID()+crypto.randomUUID().replaceAll("-","");await env.CATALOG_KV.put("session:"+token,"1",{expirationTtl:86400});return json({ok:true},200,{"Set-Cookie":`olumajang_admin=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=86400`});
  }catch(e){return json({ok:false},400)}
 }
 if(p==="/api/catalog"&&request.method==="POST"){
  if(!await authed(request,env))return json({error:"unauthorized"},401);
  let b=await request.json();if(!b||!Array.isArray(b.shops))return json({error:"bad catalog"},400);await env.CATALOG_KV.put("catalog",JSON.stringify(b));return json({ok:true});
 }
 if(p==="/api/image"&&request.method==="POST"){
  if(!await authed(request,env))return json({error:"unauthorized"},401);
  let form=await request.formData(),file=form.get("file");if(!(file instanceof File))return json({error:"file required"},400);if(file.size>12*1024*1024)return json({error:"file too large"},413);
  let id=crypto.randomUUID();await env.CATALOG_KV.put("img:"+id,await file.arrayBuffer(),{metadata:{contentType:file.type||"image/jpeg"}});return json({ref:"remote:"+id});
 }
 if(p.startsWith("/api/image/")&&request.method==="GET"){
  let id=decodeURIComponent(p.slice(11));let obj=await env.CATALOG_KV.getWithMetadata("img:"+id,"arrayBuffer");if(!obj.value)return new Response("Not found",{status:404});return new Response(obj.value,{headers:{"Content-Type":obj.metadata?.contentType||"image/jpeg","Cache-Control":"public, max-age=31536000, immutable"}});
 }
 return env.ASSETS.fetch(request);
}};
