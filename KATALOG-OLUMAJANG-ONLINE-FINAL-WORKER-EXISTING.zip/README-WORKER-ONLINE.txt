KATALOG OLUMAJANG - ONLINE
Target Worker: olumajang
KV namespace: katalog-olumajang

PENTING:
1. Deploy project ini ke Worker yang sudah ada: olumajang.
2. Setelah kode ter-deploy, buka Settings > Bindings.
3. Tambahkan KV Namespace dengan:
   Variable name: CATALOG_KV
   Namespace: katalog-olumajang
4. Deploy binding tersebut.
5. Setelah itu data katalog dan foto akan tersimpan online dan bisa dipakai dari HP lain.

Jangan upload ZIP ini ke uploader Static Assets saja; project ini membutuhkan Worker code + API.
